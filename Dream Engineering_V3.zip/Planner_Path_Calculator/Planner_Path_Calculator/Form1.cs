﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;




namespace Planner_Path_Calculator
{
    public partial class Form1 : Form
    {
        // Create a String to hold the database connection string.
        // NOTE: Put in a real database connection string here or runtime won't work
        string sdwConnectionString = @"Data Source = MATTEO\SQLEXPRESS; user id=sa; password=planner; Initial Catalog = Tree_Collection;";

        SqlConnection sdwDBConnection;

        //inizializza Depth, Split-Size e liste di attributi per nodi e archi e il tipo di ogni albero
        String Tipo = String.Empty;
        int Split_size = -1;
        int Depth = -1;
        List<string> Vertex_Attrs_List = new List<string>();
        List<string> Edge_Attrs_List = new List<string>();

        public Form1()
        {
            InitializeComponent();
            
            progressBar1.Visible = false;
            textBox1.Visible = false;

            // Create a connection
            sdwDBConnection = new SqlConnection(sdwConnectionString);
            // Open the connection
            sdwDBConnection.Open();

        }

        private async void button1_Click(object sender, EventArgs e)
        {
            progressBar1.Visible = true;
            textBox1.Visible = false;

            Vertex_Attrs_List.Clear();
            Edge_Attrs_List.Clear();


            //ATTENZIONE CANCELLA TUTTI I NODI PRECEDENTEMENTE CREATI!!! (ci serve solo per i test)            
            SqlCommand del = new SqlCommand("DELETE FROM AttrUsage DELETE FROM AttrDef DELETE FROM Vertex_Edge", sdwDBConnection);
            del.ExecuteNonQuery();

            //prende i parametri in input
            Split_size = Convert.ToInt16(textBox2.Text);
            Depth = Convert.ToInt16(textBox3.Text);
            Tipo = Input_Tipo.Text;

            #region inserimento_attributi
            if (Attr_Nodo1.Text != "")
                insert_Attr_Nodo(Attr_Nodo1.Text);

            if (Attr_Nodo2.Text != "")
                insert_Attr_Nodo(Attr_Nodo2.Text);

            if (Attr_Nodo3.Text != "")
                insert_Attr_Nodo(Attr_Nodo3.Text);

            if (Attr_Nodo4.Text != "")
                insert_Attr_Nodo(Attr_Nodo4.Text);

            if (Attr_Nodo5.Text != "")
                insert_Attr_Nodo(Attr_Nodo5.Text);

            if (Attr_Arco1.Text != "")
                insert_Attr_Arco(Attr_Arco1.Text);

            if (Attr_Arco2.Text != "")
                insert_Attr_Arco(Attr_Arco2.Text);

            if (Attr_Arco3.Text != "")
                insert_Attr_Arco(Attr_Arco3.Text);

            if (Attr_Arco4.Text != "")
                insert_Attr_Arco(Attr_Arco4.Text);

            if (Attr_Arco5.Text != "")
                insert_Attr_Arco(Attr_Arco5.Text);
            #endregion

            //questa region non ci interessa, ma ci è stata utile per capire come comunicare col database
            #region comunicazione_db
            // Create a String to hold the query.
            string show = "SELECT * FROM AttrUsage";

            // Create a SqlCommand object and pass the constructor the connection string and the query string.
            SqlCommand queryCommand = new SqlCommand(show, sdwDBConnection);

            // Use the above SqlCommand object to create a SqlDataReader object.
            SqlDataReader queryCommandReader = queryCommand.ExecuteReader();

            // Create a DataTable object to hold all the data returned by the query.
            DataTable dataTable = new DataTable();

            // Use the DataTable.Load(SqlDataReader) function to put the results of the query into a DataTable.
            dataTable.Load(queryCommandReader);

            // Example 2 - Print the first 10 row of data
            /* int topRows = 2;
             String rowText = string.Empty;
             for (int i = 0; i < topRows; i++)
             {

                 foreach (DataColumn column in dataTable.Columns)
                 {
                     rowText += dataTable.Rows[i][column.ColumnName] + " , ";
                 }

             }
             */
            // textBox1.Text = rowText; 
            #endregion            


            object ID_Root = insert_Root();

            //appende tanti figli al nodo root quanto è il valore della split_size e della depth
            //e lo fa tramite il seguente metodo ricorsivo
            await Task.Run(() => { append_children(ID_Root, "0"); });



            //si arriva qui quando tutti i nodi sono stati aggiunti
            progressBar1.Visible = false;
            textBox1.Visible = true;
            textBox1.Text = "Operazione completata, controlla il database!";
        }

        void append_children(object padre, string nomedelpadre) //depth-first
        {
            //controllo che "padre" non si trovi già all'ultimo livello
            SqlCommand cmd = new SqlCommand("SELECT (CAST('" + padre + "' AS hierarchyid)).GetLevel()", sdwDBConnection);
            int level = Convert.ToInt16(cmd.ExecuteScalar());

            if (level + 1 < Depth)
            {

                //genera valori per il figlio1
                int altezza = (int)Char.GetNumericValue(nomedelpadre.Last());
                string Name = nomedelpadre + (altezza + 1).ToString();
                //string Tipo = RandomString(3);
                Random Valore = new Random();

                //inserisce primo figlio sotto al padre selezionato
                #region inserimento primo figlio
                //individua l'ID_Gerarchico che dovrà avere
                string query = "SELECT CAST('" + padre + "' AS hierarchyid).GetDescendant(NULL, NULL)";
                cmd.CommandText = query;
                var primo_figlio = cmd.ExecuteScalar();

                string figlio1 = "INSERT Vertex_Edge (ID_Gerarchico, Name, Tipo) VALUES( CAST('" + primo_figlio + "' AS hierarchyid), '" + Name + "', '" + Tipo + "') ";

                //dichiarazione della variabile @ID_Blocco che conterrà l'id univoco di figlio1
                figlio1 = figlio1 + "DECLARE @ID_Blocco uniqueidentifier SELECT @ID_Blocco = ID_Blocco FROM Vertex_Edge WHERE Name = '" + Name + "' ";

                //si aggiungono le query di inserimento degli attributi
                foreach (string ID_Attr in Vertex_Attrs_List.Concat(Edge_Attrs_List))
                {
                    figlio1 = figlio1 + "INSERT AttrUsage (ObjectUid,AttrDefUid, Value) VALUES (@ID_Blocco, '" + ID_Attr + "','" + Valore.Next(1, 50) + "') ";
                }

                cmd.CommandText = figlio1;
                cmd.ExecuteNonQuery();
                #endregion

                append_children(primo_figlio, Name);
                object precedente = null;

                for (int k = 2; k <= Split_size; k++)
                {
                    //string Name_figlio_precedente = Name;

                    //genera valori per il figlio successivo
                    Name = nomedelpadre + (altezza + k).ToString();
                    //Tipo = RandomString(3);


                    if (k == 2)
                        precedente = primo_figlio;

                    //inserisce nodo successivo alla destra del nodo precedente
                    #region inserimento figlio corrente
                    //individua l'ID Gerarchico che dovrà avere
                    string query1 = "SELECT CAST('" + padre + "' AS hierarchyid).GetDescendant( CAST('" + precedente + "' AS hierarchyid), NULL)";
                    cmd.CommandText = query1;
                    var current_child = cmd.ExecuteScalar();

                    string figlio_corrente = "INSERT Vertex_Edge (ID_Gerarchico, Name, Tipo) VALUES( CAST('" + current_child + "' AS hierarchyid), '" + Name + "', '" + Tipo + "') ";

                    //dichiarazione della variabile @ID_Blocco che conterrà l'id univoco di figlio_corrente
                    figlio_corrente = figlio_corrente + "DECLARE @ID_Blocco uniqueidentifier SELECT @ID_Blocco = ID_Blocco FROM Vertex_Edge WHERE Name = '" + Name + "' ";

                    //si aggiungono le query di inserimento degli attributi
                    foreach (string ID_Attr in Vertex_Attrs_List.Concat(Edge_Attrs_List))
                    {
                        figlio_corrente = figlio_corrente + "INSERT AttrUsage (ObjectUid,AttrDefUid, Value) VALUES (@ID_Blocco, '" + ID_Attr + "','" + Valore.Next(1, 50) + "') ";
                    }

                    cmd.CommandText = figlio_corrente;
                    cmd.ExecuteNonQuery();
                    #endregion

                    append_children(current_child, Name);

                    precedente = current_child;
                }
            }



        }

        public static string RandomString(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            var random = new Random();
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }

        void insert_Attr_Nodo(string name)
        {
            SqlCommand insertattr = new SqlCommand("INSERT INTO AttrDef(Name) VALUES('" + name + "')", sdwDBConnection);
            insertattr.ExecuteNonQuery();
            SqlCommand query = new SqlCommand("SELECT AttrDefUid FROM AttrDef WHERE Name = '" + name + "'", sdwDBConnection);
            Vertex_Attrs_List.Add(query.ExecuteScalar().ToString());

        }

        void insert_Attr_Arco(string name)
        {
            SqlCommand insertattr = new SqlCommand("INSERT INTO AttrDef(Name) VALUES('" + name + "')", sdwDBConnection);
            insertattr.ExecuteNonQuery();
            SqlCommand query = new SqlCommand("SELECT AttrDefUid FROM AttrDef WHERE Name = '" + name + "'", sdwDBConnection);
            Edge_Attrs_List.Add(query.ExecuteScalar().ToString());
        }

        object insert_Root()
        {
            //genera valori per il nodo root
            string Name = "0";
            //string Tipo = RandomString(3);
            Random Valore = new Random();

            //inserisce nodo root
            SqlCommand root = new SqlCommand("INSERT Vertex_Edge (ID_Gerarchico, Name, Tipo) SELECT hierarchyId::GetRoot(), '" + Name + "', '" + Tipo + "'", sdwDBConnection);
            root.ExecuteNonQuery();
            //inserisce i suoi attributi (solo quelli in Vertex_Attr_List perchè la root non comprende un arco superiore)
            foreach (String Id_Attr in Vertex_Attrs_List)
            {
                SqlCommand attr = new SqlCommand("DECLARE @Nodo uniqueidentifier SELECT @Nodo = ID_Blocco FROM Vertex_Edge WHERE Name= '" + Name + "' INSERT AttrUsage (ObjectUid,AttrDefUid, Value) VALUES (@Nodo, '" + Id_Attr + "','" + Valore.Next(1, 50) + "')", sdwDBConnection);
                attr.ExecuteNonQuery();
            }

            //individua l'ID gerarchico del nodo root inserito
            string query = "SELECT ID_Gerarchico FROM Vertex_Edge WHERE Name='" + Name + "'";
            SqlCommand sel_Padre = new SqlCommand(query, sdwDBConnection);
            var Padre = sel_Padre.ExecuteScalar();
            return Padre;
        }
    }
}